<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Bookolab extends Theme
{
    // Access plugin events in this class
}
